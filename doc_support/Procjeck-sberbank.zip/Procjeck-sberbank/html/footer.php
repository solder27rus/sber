<div class="container">
  <footer class="py-3 my-4">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/index.php">Главная</a>
        </li>
        <?php
    //Проверяем авторизован ли пользователь
    if(isset($_SESSION['email']) && isset($_SESSION['password'])){
        // если нет, то выводим блок с ссылками на страницу регистрации и авторизации
?>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/form_zaim.php">Займы</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/form_invest.php">Ивестиции</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/form_cart.php">Карты</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/form_profil.php">Профиль</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/news.php">Новости</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/form_support.php">Поддержка</a>
        </li>
        <?php
    }
?>
    </ul>
    <p class="text-center text-muted">Россия, Хабаровск, 117997, ул. Вавилова, 19<br>
                                      © 1997—2022 ПАО Сбербанк.</p>
                                      <?php
    //Проверяем авторизован ли пользователь
    if(isset($_SESSION['email']) && isset($_SESSION['password'])){
        // если нет, то выводим блок с ссылками на страницу регистрации и авторизации
?>
    <button class="open-button btn btn-success" onclick="openForm()">Чат</button>
<?php
    }
?>
<div class="chat-popup text-center" id="myForm">
  <form class="form-container bg-success">
    <!-- action="action_page.php" method="post"> -->
    <h1 style="color:black">Чат</h1>

    <label style="color:black" for="msg"><b>Сообщение</b></label>
    <input type="text" class="input" placeholder="Тема:" name="tema">
    <textarea placeholder="Описание:" name="otzuv" required></textarea>

    <button type="button" class="btn btn-outline-white" onclick="SendMessage()">Отправить</button>
    <button type="button" class="btn btn-outline-white" name="btn_cancel" onclick="closeForm()">Закрыть</button>
  </form>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
async function SendMessage(){
  let message = {
    motzuv: document.getElementsByName('otzuv')[0].value,
    mtema: document.getElementsByName('tema')[0].value
  }
  let fetcher = await fetch('../server/chat.php',{
    method:'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(message),
  })
  .then((result) => result.ok === true ? result.json() : false)
      .then((data) => console.log("Success", data))
      .catch(error => console.error("Error", error));
  document.getElementsByName('otzuv')[0].value='';
  document.getElementsByName('tema')[0].value='';
  alert('Администрация ответит в кратчайшее время, ответ будет в вашем профиле в разделе поддержка.');
}
</script>
</footer>
</div>
    
    <!-- футер сайта -->
    <script src="/js/bootstrap.js"></script>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js'></script>
<script  src="/js/script.js"></script>
<script src="/js/js_news.js"></script>
<script src="/js/cookie_jquery.js"></script>
</body>
</html>