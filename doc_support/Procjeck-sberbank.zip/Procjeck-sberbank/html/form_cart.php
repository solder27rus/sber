    <!-- шапка сайта -->
    <?php
include("header.php");
?>
    <!-- шапка сайта -->
      <div class="container">
      <h2 class="pb-2 border-bottom">Страница оформления карт:</h2>
        <div class="card card-cover h-100 overflow-hidden text-white bg-success rounded-5 shadow-lg main5" style=" display: flex; flex-direction: row;">
        <img  class="img" src="/media/img/cart.jpg">
        <div class="container">
        <div class="main5text" style="display: flex; flex-direction: column;">
        <div class="" style="height:100px;"></div>
            <h1 class="main5text1">Карты </h1>
            Ба́нковская ка́рта — пластиковая, металлическая или виртуальная карта, обычно привязанная к одному или нескольким расчётным счетам в банке.
            Используется для оплаты товаров и услуг, в том числе через Интернет, с использованием бесконтактной технологии, совершения переводов, а также снятия наличных.
           <div class="main5text2">Наша лучшая карта на каждый день. Особые условия
        при зачислении стипендии, зарплаты и пенсии.</div>
        <div class="" style="height:100px;"></div>
        </div>
            </div>
        </div>
        
        <!-- <div class="main6">
            <div class="container px-2 py-2" id="custom-cards">
        <h2 class="pb-2 border-bottom">Ассортимент:</h2>
        <div style="display: flex; margin: 10px;">
        <div style="display: flex; flex-direction: column;">
            <div class="main6table"><img src="/media/img/mastercard.png"><a href="card_form.png" class="">Mastercard</a> 
            <div style="color:#C99E71; margin-right: 5px;">
            <br><button onclick="addck('.$arr_tovar['id'].')" id="'.$arr_tovar['id'].'" class="btn btn-success"><img src="img/shopping-bag.svg" alt="" class="">Заказ</button></div></div>

            <div class="main6table"><img src="/media/img/world.png"><a href="card_form.png" class="">World</a> 
            <div style="color:#C99E71; margin-right: 5px;">
            <br><button onclick="addck('.$arr_tovar['id'].')" id="'.$arr_tovar['id'].'" class="btn btn-success"><img src="img/shopping-bag.svg" alt="" class="">Заказ</button></div></div>
        </div>
        <div style="display: flex; flex-direction: column;">
            <div class="main6table"><img src="/media/img/visa.png"><a href="card_form.png" class="">Visa</a> 
            <div style="color:#C99E71; margin-right: 5px;">
            <br><button onclick="addck('.$arr_tovar['id'].')" id="'.$arr_tovar['id'].'" class="btn btn-success"><img src="img/shopping-bag.svg" alt="" class="">Заказ</button></div></div>

            <div class="main6table"><img src="/media/img/unionpay.png"><a href="card_form.png" class="">Unionpay</a> 
            <div style="color:#C99E71; margin-right: 5px;">
            <br><button onclick="addck('.$arr_tovar['id'].')" id="'.$arr_tovar['id'].'" class="btn btn-success"><img src="img/shopping-bag.svg" alt="" class="">Заказ</button></div></div>
        </div>
        </div>
    
</div>
        </div> -->
        
        <section class="h-100 h-custom">
            
  <div class="container h-100 py-5">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col">
      <form class="">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th scope="col" class="h5">Доступные карты</th>
                <th scope="col">Зказать</th>
              </tr>
            </thead>
            <tbody>

<?php
include('../server/cart_katalog_item.php');
?>
            </tbody>
          </table>
        </div>
      </form>


      </div>
    </div>
  </div>
</section>
    <div class="b-example-divider"></div>

    <div class="b-example-divider"></div>
 
    <!-- футер сайта -->
<?php
include("footer.php");
?>
    <!-- футер сайта -->