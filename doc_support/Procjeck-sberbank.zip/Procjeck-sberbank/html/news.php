    <!-- шапка сайта -->
    <?php
include("header.php")
?>
    <!-- шапка сайта -->
   
<!-- новости сайта -->
<div class="container marketing">
<h2 class="pb-2 border-bottom">Новости:</h2>
  <div class="">
  <?php
include "../server/dbconnect.php";
if(isset($_POST["btn_submit_news"]) && !empty($_POST["btn_submit_news"])){
$get_news = mysqli_query($mysqli," SELECT * FROM news ORDER BY `id` DESC LIMIT 3");
}else{
    $get_news = mysqli_query($mysqli," SELECT * FROM news ");
}

while($arr_news = mysqli_fetch_assoc($get_news)){

    echo
    '
    <div class="">
    <div style="display: flex;align-items: center;">
    <img src="/media/img/'.$arr_news['img_news'].'" class="bd-placeholder-img rounded-circle" width="140" height="140" alt="Book">
    <div style="width: 18px"></div>
      <h2 class="fw-normal">'.$arr_news['news_zagalovok'].'</h2></div>
      <p>'.$arr_news['news_date'].'</p>
      <p><a class="btn btn-success" onclick="addck('.$arr_news['id'].')"  id="'.$arr_news['id'].'"href="../html/news_id.php">Детали »</a></p>
    </div><!-- /.col-lg-4 -->  
        ';
};
?>
  </div><!-- /.row -->
</div><!-- /.container -->
<!-- новости сайта -->


    <!-- футер сайта -->
<?php
include("footer.php")
?>
    <!-- футер сайта -->