    <!-- шапка сайта -->
    <?php
include("header.php")
    ?>
    <!-- шапка сайта -->
<main class="form-signin w-50 m-auto" style="padding: 10px;">
  <form action="/server/auth.php" method="post" name="form_auth" style="padding: 10px;">
    <h1 class="h3 mb-3 fw-normal">  <svg xmlns="http://www.w3.org/2000/svg" width="42" height="42" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
  <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
</svg>Форма авторизации</h1>
    <div class="form-floating">
      <input type="email" class="form-control" id="floatingInput" name="email"placeholder="name@example.com" required>
      <label for="floatingInput">Почта</label>
    </div>
    <span id="valid_email_message" class="mesage_error"></span>
    <div class="form-floating" style="margin-top: 10px;">
      <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Password" required>
      <label for="floatingPassword">Пароль</label>
    </div>
    <span id="valid_password_message" class="mesage_error"></span>
    <div class="form-floating text-center" style="margin-top: 10px;">
    <img src="/captcha.php" alt="Капча">
    </div>
    <div class="form-floating" style="margin-top: 10px;">
    <input type="text" name="captcha" placeholder="Проверочный код" class="form-control" id="floatingCaptcha" required>
    <label for="floatingPassword">Капча</label>
    </div>
    <input class="w-100 btn btn-lg btn-success" style="margin-top: 10px;" name="btn_submit_auth" type="submit" value="Авторизация">
    <a href="/html/form_register.php" class=""><button type="button" class="w-100 btn btn-lg btn-success" style="margin-top: 10px;">Регистрация</button></a>
    <p class="mt-5 mb-3 text-muted">Ваши данные в безопасности</p>
  </form>
</main>
    <!-- футер сайта -->
    <?php
include("footer.php")
    ?>
    <!-- футер сайта -->

