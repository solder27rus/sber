    <!-- шапка сайта -->
    <?php
include("header.php")
?>
    <!-- шапка сайта -->
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Chart.js Responsive Line Chart Demo</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="/css/cssstyle.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="container">
<h2 class="pb-2 border-bottom">Страница инвестиции:</h2>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">График</h1>
                <div class="btn-toolbar mb-2 mb-md-0">

                  <button type="button" class="btn btn-sm btn-outline-secondary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-calendar" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                    <select
                    class="text-success"
                    onchange=""
                  >
                    <option value="RUB" selected>День</option>
                    <option value="RUB" selected>Неделя</option>
                    <option value="RUB" selected>Месяц</option>
                    <option value="RUB" selected>Год</option>
                  </select>
                  </button>
                </div>
              </div>
        
              <canvas id="canvas"></canvas>
              <h2>Акции компаний</h2>
              <div class="table-responsive">
                <table class="table table-striped table-sm table-hover">
                  <thead>
                    <tr>
                      <th scope="col">№</th>
                      <th scope="col">Имя</th>
                      <th scope="col">Цена</th>
                      <th scope="col">Страна</th>
                      <th scope="col">Тикер</th>
                      <th scope="col">Купить</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
include "../server/dbconnect.php";

$get_invest = mysqli_query($mysqli," SELECT * FROM invest");


while($arr_invest = mysqli_fetch_assoc($get_invest)){

    echo
    '<tr>
           <td>'.$arr_invest['id'].'</td>
           <td>'.$arr_invest['name'].'</td>
           <td>'.$arr_invest['summ'].'</td>
           <td>'.$arr_invest['country'].'</td>
           <td>'.$arr_invest['fio'].'</td>
           <td style="width: 5%;"><button onclick="ad('.$arr_invest['id'].')" id="'.$arr_invest['id'].'" name="cartdi" class="btn btn-success"><img src="img/shopping-bag.svg" alt="" class="">Купить</button></td>
         </tr>
       ';
};
?>
                  </tbody>
                </table>
              </div>
              <!-- <b class="mt-5 mb-3 text-warning bg-success w-50 h-50">Проблемы с биржей, приносим извенения</b> -->
              </div>

<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/1.0.2/Chart.min.js'></script><script  src="/js/jsscript.js"></script>

</body>
</html>
    <!-- футер сайта -->
    <?php
include("footer.php")
?>
    <!-- футер сайта -->