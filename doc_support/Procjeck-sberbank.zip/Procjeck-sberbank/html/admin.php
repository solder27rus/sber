  <!-- шапка сайта -->
  <?php
include("header.php");
?>
    <!-- шапка сайта -->
доделать доделать
    <section class="bg-light" style="margin: 30px;">
    <div class="container">
    <h2 class="pb-2 border-bottom">ffffffff</h2>
        <div class="row">
            <div class="col-lg-12 mb-4 mb-sm-5">
                <div class="card card-style1 border-0">
                    <div class="card-body p-1-9 p-sm-2-3 p-md-6 p-lg-7">
                        <div class="row align-items-center">
                            <div class="col-lg-6 mb-4 mb-lg-0">
                                <img src="/media/img/user-profile.png" class="w-50 h-50" alt="...">
                                <form action="" method="post" style="display: flex;" class="col">
                                <div class="containerw-25">
<input class="form-control" type="file" name = "uploadfile" disabled>
<input type="submit" value="Загрузить" name = "upload" class=" btn btn-lg btn-success" disabled>
<!-- <button type = "submit" name = "upload" class=" w-25 btn btn-success text-end "disabled>Загрузить</button> -->
</div>
                                </form>
                                <!-- <?php
include "../server/dbconnect.php";
$cinf = $_COOKIE["admin"];

$get_inf = mysqli_query($mysqli," SELECT * FROM 'admin' WHERE 'login' IN ('$cinf')" );

if($arr_inf = mysqli_fetch_assoc($get_inf)){

$id_user = $arr_inf['id'];
};
if (isset( $_POST [ 'upload' ])) {
    $avatar=['uploadfile'];
$result_query_insert = mysqli_query($mysqli,"INSERT INTO zaim (id_user, avatar) VALUES ('$id_user', '$avatar')");
// echo
};

?> -->
                            </div>
                            <div class="col-lg-6 px-xl-10">
                                <div class="bg-success d-lg-inline-block py-1-9 px-1-9 px-sm-6 mb-1-9 rounded">
                                    <h3 class="h2 text-white p-1 w-100">Пользователь</h3>
                                </div>
                                    <?php
                                    include("../server/inf_users.php")
                                    ?>
                                <ul class="social-icon-style1 list-unstyled mb-0 ps-0">
                                    <li><a href="#!"><i class="ti-twitter-alt"></i></a></li>
                                    <li><a href="#!"><i class="ti-facebook"></i></a></li>
                                    <li><a href="#!"><i class="ti-pinterest"></i></a></li>
                                    <li><a href="#!"><i class="ti-instagram"></i></a></li>
                                </ul>
                                <div class="text-end">
                                <!-- <a href="/html/form_auth.php" class=""><button type="button" class="w-25 btn btn-lg btn-success">Авторизация</button></a> -->
                                <a id="link_logout" onclick="'dellinf'" href="/server/log.php"><button type="button" class="w-25 btn btn-lg btn-success">Выход</button></a>
                             </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 mb-4 mb-sm-5">
                <div>
                <h2 class="pb-2 border-bottom">Карты</h2>
                <div style="display: flex;">
<?php
include "../server/dbconnect.php";
$cart = $_COOKIE["cart"];
$get_cart = mysqli_query($mysqli," SELECT * FROM cart_katalog WHERE id IN ('$cart')" );

while($arr_cart = mysqli_fetch_assoc($get_cart)){
        
        echo
    '
         <div style="padding-left:10px;">
           <img src="/media/img/'.$arr_cart['cart_img'].'" class=""
             style="width: 120px;" alt="Book">
         </div>
       ';
    };
?></div>
</div>
            </div>
            <div class="col-lg-12 mb-4 mb-sm-5">
                <div>
                <h2 class="pb-2 border-bottom">Инвестиции</h2>
                <div style="display: flex;">
<?php
include "../server/dbconnect.php";
$cart = $_COOKIE["cart"];
$get_cart = mysqli_query($mysqli," SELECT * FROM cart_katalog WHERE id IN ('$cart')" );

while($arr_cart = mysqli_fetch_assoc($get_cart)){
        
        echo
    '
         <div style="padding-left:10px;">
           <img src="/media/img/'.$arr_cart['cart_img'].'" class=""
             style="width: 120px;" alt="Book">
         </div>
       ';
    };
?></div>
</div>
            </div>
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-12 mb-4 mb-sm-5">
                        <div class="mb-4 mb-sm-5">
                        <h2 class="pb-2 border-bottom">Займ</h2>
                            <div class="progress-text">
                                <div class="row">
                                    <div class="col-6">Выплатил</div>
                                    <div class="col-6 text-end">80%</div>
                                </div>
                            </div>
                            <div class="custom-progress progress progress-medium mb-3" style="height: 4px;">
                                <div class="animated custom-bar progress-bar slideInLeft bg-success" style="width:80%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="10" role="progressbar"></div>
                            </div>
                            <div class="progress-text">
                                <div class="row">
                                    <div class="col-6">Выплатил</div>
                                    <div class="col-6 text-end">90%</div>
                                </div>
                            </div>
                            <div class="custom-progress progress progress-medium mb-3" style="height: 4px;">
                                <div class="animated custom-bar progress-bar slideInLeft bg-success" style="width:90%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="70" role="progressbar"></div>
                            </div>
                            <div class="progress-text">
                                <div class="row">
                                    <div class="col-6">Выплатил</div>
                                    <div class="col-6 text-end">50%</div>
                                </div>
                            </div>
                            <div class="custom-progress progress progress-medium mb-3" style="height: 4px;">
                                <div class="animated custom-bar progress-bar slideInLeft bg-success" style="width:50%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="70" role="progressbar"></div>
                            </div>
                            <div class="progress-text">
                                <div class="row">
                                    <div class="col-6">Выплатил</div>
                                    <div class="col-6 text-end">60%</div>
                                </div>
                            </div>
                            <div class="custom-progress progress progress-medium" style="height: 4px;">
                                <div class="animated custom-bar progress-bar slideInLeft bg-success" style="width:60%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="70" role="progressbar"></div>
                            </div>
                        </div>
                        <div>
                        <h2 class="pb-2 border-bottom">Ваши сообщения</h2>
                            <p>Здесь отображаются ваши сообщения и ответы на них.</p>
                            <!-- <p class="mb-1-9">Находиться в разработке</p> -->
                            
                            <div  id="b04" style="border:1px solid black; display:none; padding:15px; margin-bottom:10px; width:100%;">
              <?php
              include('../server/chat_dialog.php');
              ?>
</div>

                        </div><button onclick="(document.getElementById('b04').style.display='block')" class="btn btn-success me-2">Открыть</button>
<button onclick="(document.getElementById('b04').style.display='none')" class="btn btn-success me-2">Закрыть</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- футер сайта -->
<?php
include("footer.php");
?>
    <!-- футер сайта -->