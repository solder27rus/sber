var lineChartData = {
    labels: ["2002", "2003", "2004", "2005", "2006", "2007", "2008"],
    datasets: [{
        fillColor: "rgba(220,220,220,0)",
        strokeColor: "rgba(220,180,0,1)",
        pointColor: "rgba(220,180,0,1)",
        data: [280, 30, 80, 20, 40, 10, 60]
    }, {
        fillColor: "rgba(151,187,205,0)",
        strokeColor: "rgba(151,187,205,1)",
        pointColor: "rgba(151,187,205,1)",
        data: [60, 10, 40, 30, 190, 30, 20]
    }, {
        fillColor: "rgba(151,187,205,0)",
        strokeColor: "rgba(151,187,205,1)",
        pointColor: "rgba(151,187,205,1)",
        data: [60, 10, 40, 70, 80, 30, 20]
    }, {
        fillColor: "rgba(255,0,0,0)",
        strokeColor: "rgba(255,0,0,1)",
        pointColor: "rgba(255,0,0,1)",
        data: [360, 10, 40, 130, 80, 30, 20]
    }, {
        fillColor: "rgba(151,187,205,0)",
        strokeColor: "rgba(151,187,205,1)",
        pointColor: "rgba(151,187,205,1)",
        data: [460, 30, 240, 50, 280, 630, 220]
    }, {
        fillColor: "rgba(0,255,0,0)",
        strokeColor: "rgba(0,255,0,1)",
        pointColor: "rgba(0,255,0,1)",
        data: [400, 30, 100, 50, 680, 100, 600]
    }, {
        fillColor: "rgba(0,255,0,0)",
        strokeColor: "rgba(0,255,0,1)",
        pointColor: "rgba(0,255,0,1)",
        data: [500, 30, 100, 50, 280, 100, 100]
    }, {
        fillColor: "rgba(0,255,0,0)",
        strokeColor: "rgba(0,255,0,1)",
        pointColor: "rgba(0,255,0,1)",
        data: [100, 30, 100, 50, 280, 100, 100]
    }, {
        fillColor: "rgba(0,255,0,0)",
        strokeColor: "rgba(0,255,0,1)",
        pointColor: "rgba(0,255,0,1)",
        data: [430, 530, 100, 50, 280, 100, 100]
    }, {
        fillColor: "rgba(0,25,255,0)",
        strokeColor: "rgba(0,25,255,1)",
        pointColor: "rgba(0,25,255,1)",
        data: [30, 30, 100, 350, 280, 100, 100]
    }, {
        fillColor: "rgba(12,25,0,0)",
        strokeColor: "rgba(12,25,0,1)",
        pointColor: "rgba(12,25,0,1)",
        data: [10, 30, 300, 50, 280, 100, 100]
    }, {
        fillColor: "rgba(123,255,0,0)",
        strokeColor: "rgba(123,255,0,1)",
        pointColor: "rgba(123,255,0,1)",
        data: [100, 30, 300, 50, 580, 100, 100]
    }]


}

Chart.defaults.global.animationSteps = 50;
Chart.defaults.global.tooltipYPadding = 16;
Chart.defaults.global.tooltipCornerRadius = 0;
Chart.defaults.global.tooltipTitleFontStyle = "normal";
Chart.defaults.global.tooltipFillColor = "rgba(0,200,0,0.8)";
Chart.defaults.global.animationEasing = "easeOutBounce";
Chart.defaults.global.responsive = true;
Chart.defaults.global.scaleLineColor = "black";
Chart.defaults.global.scaleFontSize = 16;

var ctx = document.getElementById("canvas").getContext("2d");
var LineChartDemo = new Chart(ctx).Line(lineChartData, {
    pointDotRadius: 10,
    bezierCurve: false,
    scaleShowVerticalLines: false,
    scaleGridLineColor: "black"
});