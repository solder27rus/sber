function addck(id){
    let news = $.cookie('news')
    // if(news){ 

    // }else{
    if(news){ 
        news = `${id}`
        $.cookie('news', news, {expires: 364, path: '/'});
    }else{
        $.cookie('news', `${id}`, {expires: 364, path: '/'});
    }
// }
};
function addd(id){
    let cart = $.cookie('cart')
    // if(cart){ 

    // }else{
    if(cart){ 
        cart += `','${id}`
        $.cookie('cart', cart, {expires: 364, path: '/'});
    }else{
        $.cookie('cart', `${id}`, {expires: 364, path: '/'});
    }
// }
};
function ad(id){
    let invest = $.cookie('invest')
    // if(cart){ 

    // }else{
    if(invest){ 
        invest += `','${id}`
        $.cookie('invest', invest, {expires: 364, path: '/'});
    }else{
        $.cookie('invest', `${id}`, {expires: 364, path: '/'});
    }
// }
};


// async function cartoform(){
//     let cartid = {
//       id_cart: document.getElementsByName('cartdi')[0].value,
//       number_cart: Math.random(1000000000,9999999999),
//       cvv_cart: Math.random(100,999),
//       cart_password :Math.random(1000,9999)
//     }
//     let fetcher = await fetch('../server/cart_users_id.php',{
//       method:'POST',
//       headers: { 'Content-Type': 'application/json' },
//       body: JSON.stringify(cartid),
//     })
//     .then((result) => result.ok === true ? result.json() : false)
//         .then((data) => console.log("Success", data))
//         .catch(error => console.error("Error", error));
//     document.getElementsByName('otzuv')[0].value='';
//     document.getElementsByName('tema')[0].value='';
//     alert('Администрация ответит в кратчайшее время, ответ будет в вашем профиле в разделе поддержка.');
//   }