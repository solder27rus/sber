    <!-- шапка сайта -->
<?php
include("html/header.php")
?>
    <!-- шапка сайта -->
    <div class="container">
    <h2 class="pb-2 border-bottom">Слайдер с информацией:</h2>
    <!-- Слайдер сайта -->
    <div id="carouselExampleDark" class="text-center carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button style="background-color: #46cc4e;"type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button style="background-color: #46cc4e;" type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button style="background-color: #46cc4e;"type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
    <button style="background-color: #46cc4e;"type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="3" aria-label="Slide 4"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="10000">
      <img src="/media/img/sber_01.gif" class="d-inline" alt="/media/img/sber_01.gif">
      <div class="carousel-caption d-none d-md-inline"style="background-color: black;opacity: .9;
    border-radius: 15px;
">
        <h5 style="color: #46cc4e;">Мобильное приложение «Сбербанк Онлайн»</h5>
        <p style="color: #46cc4e;">Мобильное приложение Сбербанка установили более 50 млн пользователей.</p>
      </div>
    </div>
    <div class="carousel-item center-block" data-bs-interval="2000">
      <img src="/media/img/sber_03.gif" class="img-fluid" alt="/media/img/sber_03.gif">
      <div class="carousel-caption d-none d-md-inline"style="background-color: black;opacity: .9;
    border-radius: 15px;
">
        <h5 style="color: #46cc4e;">Перемены</h5>
        <p style="color: #46cc4e;">С нами в мир.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="/media/img/sber_01.gif" class="d-inline img-fluid" alt="/media/img/sber_01.gif">
      <div class="carousel-caption d-none d-md-inline" style="background-color: black;opacity: .9;
    border-radius: 15px;
">
        <h5 style="color: #46cc4e;">Перемены</h5>
        <p style="color: #46cc4e;">с нами в мир.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="/media/img/sber_03.gif" class="d-inline img-fluid" alt="/media/img/sber_03.gif">
      <div class="carousel-caption d-none d-md-inline"style="background-color: black;opacity: .9;
    border-radius: 15px;
">
        <h5 style="color: #46cc4e;">Мобильное приложение «Сбербанк Онлайн»</h5>
        <p style="color: #46cc4e;">Мобильное приложение Сбербанка установили более 50 млн пользователей.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div></div>
<!-- Слайдер сайта -->

<!-- конвертор -->
<script>async function AddValues(){
    let response = await fetch('https://www.cbr-xml-daily.ru/daily_json.js');
    let json = await response.json();
    // document.getElementById('curs').value = 23;
    for(let val in await json.Valute){
        document.getElementsByClassName('courses')[0].innerHTML+=
        '<option   id="getcurs" class="courses" >'+json.Valute[val]['CharCode']+'-'+json.Valute[val]['Name']+'-'+json.Valute[val]['Value']+'</option>';

    }

}
 function curses(){
        let msg = document.getElementsByClassName('courses')[0].value;
        let rar = msg.split('-');
        console.log(rar);
        document.getElementById('curs').value = document.getElementById('rub').value * rar[2];

 }
AddValues();</script>

						<form class="container" style="padding: 15px;">
            <h2 class="pb-2 border-bottom">Конвертер валют</h2>

							<div class="row mb-1">
								<div class="col">
									<label for="name">Отдаю:</label>
									<select
										disabled
										class="form-control"
										onchange=""
									>
										<option value="RUB" selected>RUB-Рубли</option>
									</select>
								</div>
								<div class="col">
									<label for="name">Получаю:</label>
									<select
                                    onchange="curses()"
										id="select"
										class="form-control courses"
									>
									</select>
								</div>
							</div>

							<div class="row">
								<div class="col">
                <label for="name">Результат:</label>
									<input
                                    onchange="curses()"
										type="text"
										class="form-control"
										id="rub"
										autofocus
									/>
								</div>
								<div class="col">
                <label for="name">:</label>
									<input      
										type="text"
										class="form-control"
										id="curs"
									/>
								</div>
							</div>
						</form>
<!-- конвертор -->

<!-- карта -->
<div class="container" style="padding: 15px;">
<h2 class="pb-2 border-bottom">Нас можно найти</h2>
<div class="container card card-cover h-100 overflow-hidden text-white bg-success rounded-3 shadow-lg" style="padding: 15px;">
<h2 class="pb-2 border-bottom">Карта одтелений города Хабаровск:</h2>
<div style="position:relative;overflow:hidden;"><a href="https://yandex.ru/maps/76/khabarovsk/search/%D0%A1%D0%B1%D0%B5%D1%80%D0%B1%D0%B0%D0%BD%D0%BA%20%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D0%B8%2C%20%D0%BE%D1%82%D0%B4%D0%B5%D0%BB%D0%B5%D0%BD%D0%B8%D1%8F/?utm_medium=mapframe&utm_source=maps" style="color:#eee;font-size:12px;position:absolute;top:0px;">Сбербанк России, отделения в Хабаровске</a><a href="https://yandex.ru/maps/76/khabarovsk/?utm_medium=mapframe&utm_source=maps" style="color:#eee;font-size:12px;position:absolute;top:14px;">Хабаровск</a><iframe src="https://yandex.ru/map-widget/v1/-/CCUJyQb1pB" width="1260" height="500" frameborder="1" allowfullscreen="true" style="position:relative;" class="rounded-bottom"></iframe></div>
</div></div>
<!-- карта -->

<!-- новости сайта -->
<div class="container marketing">
<h2 class="pb-2 border-bottom">Новости:</h2>
  <div class="row">
  <?php
include "./server/dbconnect.php";

$get_news = mysqli_query($mysqli," SELECT * FROM news ORDER BY `id` DESC LIMIT 3");


while($arr_news = mysqli_fetch_assoc($get_news)){

    echo
    '
    <div class="col-lg-4">
    <img src="/media/img/'.$arr_news['img_news'].'" class="bd-placeholder-img rounded-circle" width="140" height="140" alt="Book">
      <h2 class="fw-normal">'.$arr_news['news_zagalovok'].'</h2>
      <p>'.$arr_news['news_date'].'</p>
      <p><a class="btn btn-success" onclick="addck('.$arr_news['id'].')"  id="'.$arr_news['id'].'"href="../html/news_id.php">Детали »</a></p>
    </div><!-- /.col-lg-4 -->  
        ';
};
?>

<!-- новости сайта -->


    <!-- футер сайта -->
<?php
include("html/footer.php")
?>
    <!-- футер сайта -->