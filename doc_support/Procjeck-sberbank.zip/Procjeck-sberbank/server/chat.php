<?php 
session_start();
 //Добавляем файл подключения к БД
 include("dbconnect.php");
?>
<?php
if($_POST !== null){
    // var_dump($_POST);
    $result = json_decode(file_get_contents('php://input'), true);
    var_dump($result);
}
$cchat = $_COOKIE["inf"];

$get_chat = mysqli_query($mysqli," SELECT * FROM users WHERE email IN ('$cchat')" );

if($arr_chat = mysqli_fetch_assoc($get_chat)){
            $tema = $result['mtema'];
            $otzuv = $result['motzuv'];
            $id = $arr_chat['id'];
            $email = $arr_chat['email'];
            $ot = mysqli_query($mysqli,"INSERT INTO chat_users (id_user, messeg, date, tema) VALUES ('$id', '$otzuv', '$email', '$tema')");
            // var_dump($get_chat);
            var_dump($ot);
            var_dump($arr_chat);
            var_dump($id);
            var_dump($otzuv);
            var_dump($email);
            var_dump($tema);
            // header("HTTP/1.1 301 Moved Permanently");
            // header("Location: ".$address_site."/index.php");
        };
?>