<?php
include "dbconnect.php";

$cinf = $_COOKIE["inf"];

$get_inf = mysqli_query($mysqli," SELECT * FROM users WHERE email IN ('$cinf')" );

if($arr_inf = mysqli_fetch_assoc($get_inf)){

    echo
    '<ul class="list-unstyled mb-1-9 p-1">
    <li class="mb-2 mb-xl-3 display-28"><span class="display-26 text-success me-2 font-weight-600">Имя:</span> <input type="text" class="form-control" name="" id="" value="'.$arr_inf['first_name'].'"></li>
    <li class="mb-2 mb-xl-3 display-28"><span class="display-26 text-success me-2 font-weight-600">Отчество:</span> <input type="text" class="form-control" name="" id="" value="'.$arr_inf['midel_name'].'"></li>
    <li class="mb-2 mb-xl-3 display-28"><span class="display-26 text-success me-2 font-weight-600">Фамилия:</span> <input type="text" class="form-control" name="" id="" value="'.$arr_inf['last_name'].'"></li>
    <li class="mb-2 mb-xl-3 display-28"><span class="display-26 text-success me-2 font-weight-600">Пароль:</span> <input type="password" class="form-control" name="" id="" value="'.$arr_inf['password'].'"></li>
    <li class="mb-2 mb-xl-3 display-28"><span class="display-26 text-success me-2 font-weight-600">Почта:</span> <input type="email" class="form-control" name="" id="" value="'.$arr_inf['email'].'"></li>
</ul>';
};
?>
