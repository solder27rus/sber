<?php

$host = 'localhost';
$name = 'root';//root
$password = '';
$db = 'dbsber';//a0655007_cof

$mysqli = mysqli_connect($host, $name, $password);
mysqli_select_db($mysqli,'dbsber');//cof
if ($mysqli == false) {
    // printf("Сообщение ошибки: %s\n", mysqli_error($mysqli));
}
mysqli_set_charset($mysqli, 'utf8');
$address_site = "http://procjeck-sberbank";

?>