<?php
include "dbconnect.php";

$get_invest = mysqli_query($mysqli," SELECT * FROM invest");


while($arr_invest = mysqli_fetch_assoc($get_invest)){

    echo
    '<tr>
           <td>'.$arr_invest['id'].'</td>
           <td>'.$arr_invest['name'].'</td>
           <td>'.$arr_invest['summ'].'</td>
           <td>'.$arr_invest['country'].'</td>
           <td>'.$arr_invest['fio'].'</td>
           <td style="width: 5%;"><button onclick="addd('.$arr_invest['id'].')" id="'.$arr_invest['id'].'" class="btn btn-success" disabled>Купить</td>
         </tr>
       ';
};
?>