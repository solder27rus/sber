<?php
    //Запускаем сессию
    session_start();
 
    //Добавляем файл подключения к БД
    include("dbconnect.php");
 
    //Объявляем ячейку для добавления ошибок, которые могут возникнуть при обработке формы.
    $_SESSION["error_messages"] = '';
 
    //Объявляем ячейку для добавления успешных сообщений
    $_SESSION["success_messages"] = '';
?>
<?php
$cinf = $_SESSION['info'];

$get_inf = mysqli_query($mysqli," SELECT * FROM users WHERE email IN ('$cinf')" );

if($arr_inf = mysqli_fetch_assoc($get_inf)){

$id_user = $arr_inf['id'];
};

$id_user = htmlspecialchars($id_user, ENT_QUOTES);

    $summ = trim($_POST["totalpricee"]);

        $summ = htmlspecialchars($summ, ENT_QUOTES);

    $summ_y = trim($_POST["totalprice"]);

        $summ_y  = htmlspecialchars($summ_y , ENT_QUOTES);

        $summ_m = trim($_POST["totalprice12"]);

        $summ_m = htmlspecialchars($summ_m, ENT_QUOTES);

    $summ_w = trim($_POST["totalprice52"]);

    $summ_w = htmlspecialchars($summ_w, ENT_QUOTES);
// echo
// $summ_w; 
// echo
// $summ_m; 
// echo
// $summ_y;
// echo
// $id_user;
//Запрос на добавления
$result_query_insert = mysqli_query($mysqli,"INSERT INTO zaim (id_user, summ, summ_w, summ_m, summ_y) VALUES ('$id_user', '$summ', '$summ_w', '$summ_m', '$summ_y')");
// echo
// $result_query_insert;
header("HTTP/1.1 301 Moved Permanently");
header("Location: $address_site/html/form_zaim.php");
?>