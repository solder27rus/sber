<?php 
session_start();
 //Добавляем файл подключения к БД
 include("dbconnect.php");
?>
<?php
if($_POST !== null){
    // var_dump($_POST);
    $result = json_decode(file_get_contents('php://input'), true);
    var_dump($result);
}
$cchat = $_COOKIE["inf"];

$get_chat = mysqli_query($mysqli," SELECT * FROM users WHERE email IN ('$cchat')" );

if($arr_chat = mysqli_fetch_assoc($get_chat)){
            $tema = $result['mtema'];
            $otzuv = $result['motzuv'];
            $id = $arr_chat['id'];
            $email = $arr_chat['email'];
            $ot = mysqli_query($mysqli,"INSERT INTO `cart_user` (id_cart, id_users, cart_number, cart_cvv, cart_password) VALUES ('$id', '$otzuv', '$email', '$tema')");
            
            var_dump($ot);
            // header("HTTP/1.1 301 Moved Permanently");
            // header("Location: ".$address_site."/index.php");
        };
?>