<?php
include('dbconnect.php');

$cinf = $_COOKIE["inf"];

$get_inf = mysqli_query($mysqli," SELECT * FROM users WHERE email IN ('$cinf')" );
$get_invest = mysqli_query($mysqli," SELECT * FROM chat_users");
// $get_invest = mysqli_query($mysqli," SELECT * FROM chat_admin");
$summ =0;
while($arr_inf = mysqli_fetch_assoc($get_inf)){

    $id=$arr_inf['id'];
    };
while($arr_invest = mysqli_fetch_assoc($get_invest)){
$summ+=1;
if($arr_invest['id_user'] == $id){
echo'
<div>
                        <h2 class="pb-2 border-bottom">Тема:'.$arr_invest['tema'].'</h2>
                            <p style="font-size: 17px;">Cообщение:'.$arr_invest['messeg'].'</p>
                            <p class="text-danger"style="font-size: 17px;">Ответ:'.$arr_invest['otvet'].'</p>
                            <!-- <p class="mb-1-9">Находиться в разработке</p> -->
                        </div>
';};
};
?>