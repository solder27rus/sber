<?php 
  $do = $_GET['do']; 
  switch($do) { 
      case 'check_password_strength': 
          $password = $_GET['pass']; 
          $strength = 0; 
          // буквы (маленькие) 
          if(preg_match("/([a-z]+)/", $password)) { 
              $strength++; 
          } 
          // буквы (большие) 
          if(preg_match("/([A-Z]+)/", $password)) { 
              $strength++; 
          } 
          // числа 
          if(preg_match("/([0-9]+)/", $password)) { 
              $strength++; 
          } 
          // символы 
          if(preg_match("/(W+)/", $password)) { 
              $strength++; 
          } 
          header('Content-Type: text/xml'); 
          header('Pragma: no-cache'); 
          echo '<?xml version="1.0" encoding="UTF-8"?>'; 
          echo '<result><![CDATA['; 
          switch($strength) { 
              case 1: 
  
                  echo '<div style="width: 25%" id="password_bar">Очень легкий</div>'; 
              break; 
              case 2: 
                  echo '<div style="width: 50%" id="password_bar">Легкий</div>'; 
              break; 
              case 3: 
                  echo '<div style="width: 75%" id="password_bar">Сложный</div>'; 
              break; 
              case 4: 
                  echo '<div style="width: 100%" id="password_bar">Очень сложный</div>'; 
              break; 
          } 
          echo ']]></result>'; 
      break; 
      default: 
          echo 'Error, invalid action'; 
      break; 
  } 
  ?> 