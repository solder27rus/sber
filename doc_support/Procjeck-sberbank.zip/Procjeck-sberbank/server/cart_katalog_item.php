<?php
include "dbconnect.php";

$get_cart = mysqli_query($mysqli," SELECT * FROM cart_katalog");


while($arr_cart = mysqli_fetch_assoc($get_cart)){

    echo
    ' <tr>
       <th scope="row" class="border-bottom-0">
         <div class="d-flex align-items-center">
           <img src="/media/img/'.$arr_cart['cart_img'].'" class="bd-placeholder-img rounded-circle" width="140" height="140" alt="Book">
           <div class="flex-column ms-4">
             <p class="mb-2">'.$arr_cart['name'].'</p>
             <p class="mb-0 w-75">'.$arr_cart['cart_text'].'</p>
           </div>
         </div>
       </th>
       <td class="align-middle border-bottom-0">
         <div class="d-flex flex-row">
         <button onclick="addd('.$arr_cart['id'].')" id="'.$arr_cart['id'].'" name="cartdi" class="btn btn-success"><img src="img/shopping-bag.svg" alt="" class="">Заказать</button></div></div>
     </tr>
       ';
};
?>