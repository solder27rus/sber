<?php
    //Запускаем сессию
    session_start();
 
    unset($_SESSION["email"]);
    unset($_SESSION["password"]);
    unset($_COOKIE['inf']);
    setcookie('admin','',0,'/');
    setcookie('cart','',0,'/');
    // Возвращаем пользователя на ту страницу, на которой он нажал на кнопку вход.
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: ".$address_site."/html/form_admin.php");
    
?>