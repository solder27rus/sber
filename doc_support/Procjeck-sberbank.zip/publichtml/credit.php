<?php 
session_start();
 //Добавляем файл подключения к БД
 include("dbconnect.php");
?>
<?php
$cinf = $_COOKIE["inf"];

$get_tovar = mysqli_query($mysqli," SELECT * FROM users WHERE email IN ('$cinf')" );

if($arr_inf = mysqli_fetch_assoc($get_tovar)){

            
            $name = $arr_inf['first_name'];
            $last = $arr_inf['last_name'];
            $email = $arr_inf['email'];
            $type = $_POST['type'];
            $datee = $_POST['date'];
            $cost = $_POST['cost'];

            $ot = mysqli_query($mysqli,"INSERT INTO `credit` (first_name, last_name, email, type, date, cost) VALUES ('$name', '$last', '$email', '$type', '$datee', '$cost')");
            
            // var_dump($ot);
            header("HTTP/1.1 301 Moved Permanently");
            header("Location: ".$address_site."/index.php");
        };
?>