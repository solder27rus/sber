
<footer>
    <div class="textfooter">сбер</div> 
    <button class="open-button" onclick="openForm()">Чат</button>

<div class="chat-popup" id="myForm">
  <form class="form-container">
    <!-- action="action_page.php" method="post"> -->
    <h1 style="color:black">Чат</h1>

    <label style="color:black" for="msg"><b>Сообщение</b></label>
    <textarea placeholder="Тип сообщения.." name="otzuv" required></textarea>

    <button type="button" class="btn" onclick="SendMessage()">Отправить</button>
    <button type="button" class="btn cancel" name="btn_cancel" onclick="closeForm()">Закрыть</button>
  </form>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
async function SendMessage(){
  let message = document.getElementsByName('otzuv')[0].value;
  let fetcher = await fetch('action_page.php',{
    method:'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify( {otzuv : message} )
  })
  .then((result) => result.ok === true ? result.json() : false)
      .then((data) => console.log("Success", data))
      .catch(error => console.error("Error", error));
  document.getElementsByName('otzuv')[0].value='';
}
</script>
</footer>

</body>
<!-- <script src="forkorzin.js"></script> -->
<script src="scroll.js"></script>
<script src="tovar_kor.js"></script>
<script src="inf_pr.js"></script>
<script src="PROFIL_INF.js"></script>
<script src="course.js"></script>
</html>