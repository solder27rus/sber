<?php 
session_start();
 //Добавляем файл подключения к БД
 include("dbconnect.php");
?>
<?php
if($_POST !== null){
    var_dump($_POST);
    $result = json_decode(file_get_contents('php://input'), true);
    var_dump($result);

}
$cinf = $_COOKIE["inf"];

$get_tovar = mysqli_query($mysqli," SELECT * FROM users WHERE email IN ('$cinf')" );

if($arr_inf = mysqli_fetch_assoc($get_tovar)){

            $otzuv = $result['otzuv'];
            $name = $arr_inf['first_name'];
            $email = $arr_inf['email'];
            $ot = mysqli_query($mysqli,"INSERT INTO `otzuv` (first_name, otzuv, email) VALUES ('".$name."', '".$otzuv."', '".$email."')");
            
            var_dump($ot);
            // header("HTTP/1.1 301 Moved Permanently");
            // header("Location: ".$address_site."/index.php");
        };
?>