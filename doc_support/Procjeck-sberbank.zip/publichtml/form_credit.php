<?php
    //Подключение шапки
    include("header.php");
?>

    <div id="form_auth" class="main8content">
        <h2>Форма оформления</h2>
        <form action="credit.php" method="post" name="form_credit">
            <table>
          
                <tbody><tr>
                    <td> тип: </td>
                    <td>
                    <select
										
										class="contentmain8"
										onchange=""
                                        name="type"
									>
										<option  >ипотека</option>
                                        <option  >кредит</option>
                                        <option  >заем</option>
                                        <option  >кредит</option>
									</select>
                        
                    </td>
                </tr>
          
                <tr>
                    <td>дата </td>
                    <td>
                        <input type="date" name="date"  class="contentmain8"required="required"><br>
                        
                    </td>
                </tr>
                 
                <tr>
                    <td> цена: </td>
                    <td>
                        <p>
                        <input type="text" name="cost" placeholder="1000000000" class="contentmain8"required="required"><br>
                        
                        </p>
                    </td>
                </tr>
 
                <tr>
                    <td colspan="2">
                        <input  class="buttonreg contentmain8" type="submit" name="btn_submit_f" value="Оформить">
                    </td>
                </tr>
            </tbody></table>
        </form>
    </div>

<?php
    //Подключение подвала
    include("footer.php");
?>