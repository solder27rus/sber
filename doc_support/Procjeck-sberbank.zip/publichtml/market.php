<?php
include('header.php')
?>


    <div class="main1-all">
<div class="main5">
    <div class="mainimg5">
<img  class="cartimg" src="img/cart.jpg">
</div>
<div class="main5content">
<div class="main5text">
<div style="color:#C99E71; margin-right: 5px;">Рекомендация</div>
    <h1 class="main5text1">Карты </h1>
   <div class="main5text2">Наша лучшая карта на каждый день. Особые условия
при зачислении стипендии, зарплаты и пенсии.</div>
</div>
    </div>
</div>

<div class="main6">
<div class="main3text"></div>
<h1 class="font-family:Righteous">Ассортимент</h1>
<div style="display: flex; margin: 10px;">
<div style="display: flex; flex-direction: column;">
<?php
include('tovar.php')
?>
</div>
</div>

</div>
<?php
include('footer.php')
?>