<?php

$host = 'localhost';
$name = 'root';//root
$password = '';
$db = 'a0655007_cof';//a0655007_cof

$mysqli = mysqli_connect($host, $name, $password);
mysqli_select_db($mysqli,'a0655007_cof');//cof
if ($mysqli == false) {
    // printf("Сообщение ошибки: %s\n", mysqli_error($mysqli));
}
mysqli_set_charset($mysqli, 'utf8');
$address_site = "http://publichtml";

?>