
<?php
include('header.php')
?>

<div class='all'>
<div class="main1-all">
    <h1>Ваши заказ</h1>
<div class="tovar-oplata">
    <div class="opisanie">
        <div class="summa">
                <form action="" method="post" name="zakaz">
        <?php
        include "buykorzina.php"
        ?>
        <div class="buttonzakaz">
        <input  class="buttonpr" type="submit" name="btn_zakaz" value="Заказать">
        <input  class="buttonpr" type="submit" name="btn_zakaz_new" value="Изменить">
            </div>
    </form>
     </div>
    </div>
</div>
    </div>
        </div>
    </div>


</div>

    </div>
</div>
</div>

<?php
include('footer.php')
?>
</div>