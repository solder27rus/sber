// let usd = 12;
// let eur = 13;
// let grb = 10;
// let rub = 0;
// let curs = 0;
// function start(){
//     rub = document.getElementById('rub').innerHTML;
//     document.getElementById('curs').innerHTML = curs;
// }
// function rub_curs(){
//     curs = rub*curs;
// }