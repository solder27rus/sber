    <!-- шапка сайта -->
    <?php
include("header.php")
?>
    <!-- шапка сайта -->

    <div class="container">
  <div class="price-box">
    <div class="row">
      <div class="col-sm-6">
        <form class="form-horizontal form-pricing" role="form">

          <div class="price-slider">
            <h4 class="great">Сумма : <span class="text-white">От 100 тысяч до 2 м</span></h4>
            <div>dfsdfsdf</div>
            <div class="col-sm-28">
              <div id="slider_amirol">
              </div>
            </div>
          </div>
          <div class="price-slider">
            <h4 class="great">Продолжительность : <span class="text-white">Выберети один вариант</span></h4>
            <div class="btn-group btn-group-justified">
              <div class="btn-group btn-group-lg">
                <button type="button" class="btn btn-success btn-lg btn-block month active-month selected-month" id='24month'>24 месяцев</button>
              </div>
              <div class="btn-group btn-group-lg">
                <button type="button" class="btn btn-success btn-lg btn-block month" id='18month'>18 месяцев</button>
              </div>
              <div class="btn-group btn-group-lg">
                <button type="button" class="btn btn-success btn-lg btn-block month" id='12month'>12 месяцев</button>
              </div>
            </div>
          </div>
          <div class="price-slider">
            <h4 class="great">Срок : <span class="text-white">Выберети один вариант</span></h4>
            <input name="sliderVal" type="hidden" id="sliderVal" value='0' readonly="readonly" />
            <input name="month" type="hidden" id="month" value='24month' readonly="readonly" />
            <input name="term" type="hidden" id="term" value='quarterly' readonly="readonly" />
            <div class="btn-group btn-group-justified">
              <div class="btn-group btn-group-lg">
                <button type="button" class="btn btn-success btn-lg btn-block term active-term selected-term" id='quarterly'>Ежегодно</button>
              </div>
              <div class="btn-group btn-group-lg">
                <button type="button" class="btn btn-success btn-lg btn-block term" id='monthly'>Ежемесечно</button>
              </div>
              <div class="btn-group btn-group-lg">
                <button type="button" class="btn btn-success btn-lg btn-block term" id='weekly'>Еженедельно</button>
              </div>
            </div>
          </div>
      </div>
      <div class="col-sm-6">
        <div class="price-form">

          <div class="form-group">
            <div class="row">
              <div class="col-sm-6">
                <label for="amount_amirol" class="control-label">Ежегодно : </label>
                <span class="help-text">Сумма выплат</span>
              </div>
              <div class="col-sm-6">
                <input type="hidden" id="amount_amirol" class="form-control">
                <input class="price lead" name="totalprice" type="text" id="total" disabled="disabled" style="" />
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row">
              <div class="col-sm-6">
                <label for="amount_amirol" class="control-label">Ежемесечно : </label>
                <span class="help-text">Сумма выплат</span>
              </div>
              <div class="col-sm-6">
                <input type="hidden" id="amount_amirol" class="form-control">
                <!-- <p class="price lead" id="total12"></p> -->
                <input class="price lead" name="totalprice12" type="text" id="total12" disabled="disabled" style="" />
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row">
              <div class="col-sm-6">
                <label for="amount_amirol" class="control-label">Еженедельно : </label>
                <span class="help-text">Сумма выплат</span>
              </div>
              <div class="col-sm-6">
                <input type="hidden" id="amount_amirol" class="form-control">
                <input class="price lead" name="totalprice52" type="text" id="total52" disabled="disabled" style="" />
              </div>
            </div>
          </div>
          <div style="margin-top:30px"></div>
          <hr class="style">

          <div class="form-group">
            <div class="col-sm-12">
              <button type="submit" class="btn btn-success btn-lg btn-block">Оформить <span class="glyphicon glyphicon-chevron-right"></span></button>
            </div>
          </div>
          <div class="form-group">
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

    <!-- футер сайта -->
<?php
include("footer.php")
?>
    <!-- футер сайта -->