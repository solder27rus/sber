<!-- шапка сайта -->
<?php
include("header.php")
    ?>

     <script type="text/javascript">
    function toggle_pass(passid) {
    if (window.XMLHttpRequest) {
    http = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
    http = new ActiveXObject("Microsoft.XMLHTTP");
    }
    handle = document.getElementById(passid);
    var url = '/server/ajax.php?';
    if(handle.value.length > 0) {
    var fullurl = url + 'do=check_password_strength&pass=' + encodeURIComponent(handle.value);
    http.open("GET", fullurl, true);
    http.send(null);
    http.onreadystatechange = statechange_password;
    }else{
    document.getElementById('password_strength').innerHTML = '';
    }
    }
  function statechange_password() {
    if (http.readyState == 4) {
    var xmlObj = http.responseXML;
    var html = xmlObj.getElementsByTagName('result').item(0).firstChild.data;
    document.getElementById('password_strength').innerHTML = html;
    }
    }
  </script>
  <style type="text/css">
    input {
    border: 1px solid #000000;
    padding: 5px; 
    }
    #password_strength {
    width: 250px;
    background: #cccccc;
    }
    #password_bar {
    font-size: 11px;
    background: #7FFF00; 
    border: 1px solid #cccccc;
    padding: 5px;
    }
  </style> 

    <!-- шапка сайта -->
<main class="form-signin w-50 m-auto" style="padding: 10px;">

</main>

<?php
    if(isset($_SESSION["email"]) && isset($_SESSION["password"])){
?>
<div id="form_register" class="main8content">
<h2>Форма регистрации</h2>

<form action="/server/register.php" method="post" name="form_register" style="padding: 10px;">
    <h1 class="h3 mb-3 fw-normal">  <svg xmlns="http://www.w3.org/2000/svg" width="42" height="42" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
  <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
</svg>Форма регистрации</h1>
    <div class="form-floating">
      <input type="text" class="form-control" name="first_name" id="floatingInput" placeholder="Имя" required>
      <label for="floatingInput">Имя</label>
    </div>
    <div class="form-floating" style="margin-top: 10px;">
      <input type="text" class="form-control" name="midel_name" id="floatingPassword" placeholder="Отчество" required>
      <label for="floatingPassword">Отчество</label>
    </div>
    <div class="form-floating" style="margin-top: 10px;">
      <input type="text" class="form-control" name="last_name" id="floatingPassword" placeholder="Фамиля" required>
      <label for="floatingPassword">Фамиля</label>
    </div>
    <div class="form-floating" style="margin-top: 10px;">
      <input type="email" class="form-control" name="email" id="floatingInput" placeholder="name@example.com" required>
      <label for="floatingInput">Почта</label>
    </div>
    <div class="form-floating" style="margin-top: 10px;">
      <input type="password" class="form-control" name="password" id="pass" placeholder="Пароль" onchange="toggle_pass('pass')" required>
      <label for="floatingPassword">Пароль</label>
    </div>
    <div class="form-floating" style="margin-top: 10px;">
    <div id="password_strength"> </div>
    <div class="form-floating" style="margin-top: 10px;">
      <input type="password" class="form-control" id="floatingPassword" placeholder="Повторение" required>
      <label for="floatingPassword">Повторение пароля</label>
    </div>
    </div>
    <div class="form-floating text-center" style="margin-top: 10px;">
    <img src="/captcha.php" alt="Капча">
    </div>
    <div class="form-floating" style="margin-top: 10px;">
    <input type="text" name="captcha" placeholder="Проверочный код" class="form-control" id="floatingPassword" required>
    <label for="floatingPassword">Капча</label>
    </div>
    <div class="checkbox mb-3" style="margin-top: 10px;">
      <label>
        <input type="checkbox" value="remember-me" required> Согласие на обработку персональных данных
      </label>
    </div>
    <button class="w-100 btn btn-lg btn-success" name="btn_submit_register" type="submit">Регистрация</button>
    <a href="/html/form_auth.php" class=""><button type="button" class="w-100 btn btn-lg btn-success" style="margin-top: 10px;">Авторизация</button></a>
    <p class="mt-5 mb-3 text-muted">Ваши данные в безопасности</p>
</form>
</div>
<!-- футер сайта -->
<?php
    }else{
?>
        <div id="authorized">
            <h2>Вы уже зарегистрированы</h2>
        </div>
<?php
    }

    
include("footer.php")
    ?>
    <!-- футер сайта -->