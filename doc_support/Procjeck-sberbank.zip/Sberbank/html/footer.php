<!-- футер сайта -->
<div class="container">
  <footer class="py-3 my-4">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/index.php">Главная</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/form_zaim.php">Займы</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/form_invest.php">Ивестиции</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/form_cart.php">Карты</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/form_profil.php">Профиль</a>
        </li>
        <li class="nav-item">
          <a class="nav-link px-2 text-muted" aria-current="page" href="/html/form_support.php">Поддержка</a>
        </li>
    </ul>
    <p class="text-center text-muted">Россия, Москва, 117997, ул. Вавилова, 19<br>
                                      © 1997—2022 ПАО Сбербанк.</p>
<button class="open-button" onclick="openForm()">Чат</button>

<div class="chat-popup" id="myForm">
  <form class="form-container">
    <!-- action="action_page.php" method="post"> -->
    <h1 style="color:black">Чат</h1>

    <label style="color:black" for="msg"><b>Сообщение</b></label>
    <textarea placeholder="Тип сообщения.." name="otzuv" required></textarea>

    <button type="button" class="btn" onclick="SendMessage()">Отправить</button>
    <button type="button" class="btn cancel" name="btn_cancel" onclick="closeForm()">Закрыть</button>
  </form>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
async function SendMessage(){
  let message = document.getElementsByName('otzuv')[0].value;
  let fetcher = await fetch('action_page.php',{
    method:'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify( {otzuv : message} )
  })
  .then((result) => result.ok === true ? result.json() : false)
      .then((data) => console.log("Success", data))
      .catch(error => console.error("Error", error));
  document.getElementsByName('otzuv')[0].value='';
}
</script>
  </footer>
</div>
    
    <script src="/js/bootstrap.js"></script>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js'></script>
    <script  src="/script.js"></script>
    <!-- <script src="forkorzin.js"></script> -->
    <script src="scroll.js"></script>
    <script src="tovar_kor.js"></script>
    <script src="inf_pr.js"></script>
    <script src="PROFIL_INF.js"></script>
    <script src="course.js"></script>
</body>
</html>