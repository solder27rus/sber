    <!-- шапка сайта -->
    <?php
include("html/header.php")
?>
    <!-- шапка сайта -->
    <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="10000">
      <img src="/media/img/sber_01.gif" class="d-inline w-50 h-50" alt="/media/img/sber_01.gif">
      <div class="carousel-caption d-none d-md-inline">
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item center-block" data-bs-interval="2000">
      <img src="/media/img/sber_01.gif" class="d-inline w-50 h-50" alt="/media/img/sber_01.gif">
      <div class="carousel-caption d-none d-md-inline">
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="/media/img/sber_01.gif" class="d-inline w-50 h-50" alt="/media/img/sber_01.gif">
      <div class="carousel-caption d-none d-md-inline">
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<!-- Marketing messaging and featurettes
================================================== -->
<!-- Wrap the rest of the page in another container to center all the content. -->

<div class="container marketing">

  <!-- Three columns of text below the carousel -->
  <div class="row">
    <div class="col-lg-4">
      <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"></rect><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>

      <h2 class="fw-normal">Heading</h2>
      <p>Some representative placeholder content for the three columns of text below the carousel. This is the first column.</p>
      <p><a class="btn btn-secondary" href="#">View details »</a></p>
    </div><!-- /.col-lg-4 -->
    <div class="col-lg-4">
      <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"></rect><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>

      <h2 class="fw-normal">Heading</h2>
      <p>Another exciting bit of representative placeholder content. This time, we've moved on to the second column.</p>
      <p><a class="btn btn-secondary" href="#">View details »</a></p>
    </div><!-- /.col-lg-4 -->
    <div class="col-lg-4">
      <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 140x140" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"></rect><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>

      <h2 class="fw-normal">Heading</h2>
      <p>And lastly this, the third column of representative placeholder content.</p>
      <p><a class="btn btn-secondary" href="#">View details »</a></p>
    </div><!-- /.col-lg-4 -->
  </div><!-- /.row -->

  <script>async function AddValues(){
    let response = await fetch('https://www.cbr-xml-daily.ru/daily_json.js');
    let json = await response.json();
    // document.getElementById('curs').value = 23;
    for(let val in await json.Valute){
        document.getElementsByClassName('courses')[0].innerHTML+=
        '<option   id="getcurs" class="courses" >'+json.Valute[val]['CharCode']+'-'+json.Valute[val]['Name']+'-'+json.Valute[val]['Value']+'</option>';

    }

}
 function curses(){
        let msg = document.getElementsByClassName('courses')[0].value;
        let rar = msg.split('-');
        console.log(rar);
        document.getElementById('curs').value = document.getElementById('rub').value * rar[2];

 }
AddValues();</script>

						<form>
							<h1 class="h2 mb-4">Конвертер валют</h1>

							<div class="row mb-1">
								<div class="col">
									<label for="name">Отдаю:</label>
									<select
										disabled
										class="contentmain8"
										onchange=""
									>
										<option value="RUB" selected>RUB-Рубли</option>
									</select>
								</div>
								<div class="col">
									<label for="name">Получаю:</label>
									<select
                                    onchange="curses()"
										id="select"
										class="contentmain8 courses"
									>
									</select>
								</div>
							</div>

							<div class="row">
								<div class="col">
									<input
                                    onchange="curses()"
										type="text"
										class="contentmain8"
										id="rub"
										autofocus
									/>
								</div>
								<div class="col">
									<input
                                    
										type="text"
										class="contentmain8"
										id="curs"
									/>
								</div>
							</div>
						</form>

</div><!-- /.container -->
<div class="main8">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2643.775540339673!2d135.09191931555264!3d48.49919597925399!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5efac1fcb0d9410f%3A0x4bda7658aee59e09!2z0KHQsdC10YDQsdCw0L3Qug!5e0!3m2!1sru!2sru!4v1647525829546!5m2!1sru!2sru" width="650" height="570" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>

    <!-- футер сайта -->
<?php
include("html/footer.php")
?>
    <!-- футер сайта -->